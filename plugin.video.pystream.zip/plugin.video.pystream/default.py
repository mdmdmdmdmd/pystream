########################################################
## IMPORT
########################################################
import urllib
import urllib2
import urlparse
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import binascii

from pbkdf2 import PBKDF2
from hashlib import sha512 as SHA512


########################################################
## VARS
########################################################

addon_id = xbmcaddon.Addon('plugin.video.pystream')
base_url = 'http://' + addon_id.getSetting('pystream.host') + ':' + addon_id.getSetting('pystream.port') + '/'
index_json_url = base_url + 'api/get_index_json'
preset_json_url = base_url + 'api/get_preset_json'
add_json_url = base_url + 'api/add_vod'
media_url = base_url + 'videos/'
username = addon_id.getSetting('pystream.user')
password = binascii.b2a_base64(PBKDF2(addon_id.getSetting('pystream.pass'), b'gDR%AEtgewt4qT43', iterations=100000, digestmodule=SHA512).read(64))
pystream_version = '0.0.2'

plugin_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)

########################################################
## FUNCTIONS
########################################################

def build_url(query):
    return plugin_url + '?' + urllib.urlencode(query)

def add_sort_methods():
    xbmcplugin.addSortMethod(addon_handle, 1)

def add_directory(title, image_url, url):
    li = xbmcgui.ListItem(title, iconImage=image_url)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

def add_video_item(title, file_url, folder=False):
    li = xbmcgui.ListItem(title)
    li.setInfo('video', {'title': title})
    li.setProperty('mimetype', 'video/flv')
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=file_url, isFolder=folder, listitem=li)

def play_video():
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl( handle=addon_handle, succeeded=True, listitem=li)

def retrieve_play_url(media_id):
    req = urllib2.Request(preset_json_url + '/' + media_id, headers={'login': username, 'password': password})
    jsonurl = urllib2.urlopen(req)
    preset_json = json.loads(jsonurl.read())
    dialog = xbmcgui.Dialog()
    preset = dialog.select('Quality:', preset_json)
    if preset == -1:
        return
    play_url = media_url + media_id + '?preset=' + preset_json[preset] + '|login=' + username + '&password=' + password
    li = xbmcgui.ListItem(path=play_url)
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=li)

########################################################
## BODY
########################################################

if mode is None:
    req = urllib2.Request(index_json_url, headers={'login': username, 'password': password})
    jsonurl = urllib2.urlopen(req)
    index_json = json.loads(jsonurl.read())
    add_sort_methods()
    xbmcplugin.setContent(addon_handle, 'movies')

    if index_json:
        object_cnt = int(index_json['count'])
        if object_cnt > 0:
            for entry in index_json['list']:
                add_video_item(entry, sys.argv[0] + entry + '?mode=subdir', True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'subdir':
    xbmc.log(urlparse.urlparse(sys.argv[0])[2])
    index_json_url = index_json_url + urlparse.urlparse(sys.argv[0])[2]
    req = urllib2.Request(index_json_url, headers={'login': username, 'password': password})
    jsonurl = urllib2.urlopen(req)
    index_json = json.loads(jsonurl.read())
    add_sort_methods()
    xbmcplugin.setContent(addon_handle, 'movies')

    if index_json:
        object_cnt = int(index_json['count'])
        if object_cnt > 0:
            for entry in index_json['list']:
                add_video_item(entry, sys.argv[0] + '/' + entry + '?mode=play_video', False)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'play_video':
    retrieve_play_url(urlparse.urlparse(sys.argv[0])[2][1:])
